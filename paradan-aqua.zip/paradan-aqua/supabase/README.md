Dogrow Supabase project ref: cpszkescrhiftrhqaubu.
The database schema and affiliate/UPI backend were provisioned separately. Set the public Supabase URL and publishable/anon key as environment variables before deployment.

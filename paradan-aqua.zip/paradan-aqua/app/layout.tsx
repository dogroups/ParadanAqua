import './globals.css';
export const metadata={title:'Paradan Aqua',description:'Paradan Aqua e-commerce and affiliate platform'};
export default function Layout({children}:{children:React.ReactNode}){return <html><body>{children}</body></html>}
